package org.sid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArticleApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
